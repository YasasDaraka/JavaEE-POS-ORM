package lk.ijse.pos.bo;

public interface SuperBO {
}
